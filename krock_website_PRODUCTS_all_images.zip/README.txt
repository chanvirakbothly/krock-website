KROCK Website (Khmer + English)
1) Open index.html in your browser.
2) Edit translations and text in assets/app.js (I18N dictionary).
3) Edit product specs in products.html and projects in projects.html.
4) To publish: upload the entire folder to any hosting (Netlify, Vercel static, cPanel, GitHub Pages).
